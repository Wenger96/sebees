import React from "react";
import "./style.css";

export const Page = () => {
  return (
    <div className="page">
      <div className="top-bar">
        <img
          className="whatsapp-image"
          alt="Whatsapp image"
          src="https://c.animaapp.com/GXcfFNUM/img/whatsapp-image-2024-01-13-at-11-33-1@2x.png"
        />
        <div className="title">SEBEES FRESH FOOD LTD</div>
        <div className="navbar">
          <div className="tab">Home</div>
          <div className="tab">About</div>
          <div className="tab">Shop</div>
          <div className="tab">Contact</div>
          <div className="textfield">
            <div className="text">Search in site</div>
            <img className="ic-search" alt="Ic search" src="https://c.animaapp.com/GXcfFNUM/img/ic-search.svg" />
          </div>
        </div>
      </div>
      <div className="section">
        <div className="container">
          <p className="text-wrapper">Welcome to SEBEES FRESH FOODS</p>
          <p className="description">a brand you can always trust</p>
          <button className="button">
            <div className="primary">
              <div className="div">Shop Now</div>
            </div>
          </button>
        </div>
        <img className="vector" alt="Vector" src="https://c.animaapp.com/GXcfFNUM/img/vector-200-2.svg" />
      </div>
      <div className="section-2">
        <div className="container-2">
          <div className="text-wrapper">Featured Products</div>
          <p className="description">Discover our wide range of fresh farm produce</p>
          <button className="button">
            <div className="primary">
              <div className="div">View All Products</div>
            </div>
          </button>
          <div className="list">
            <div className="card">
              <div className="image-container" />
              <div className="subtitle">
                Special Boneless Beef
                <br />
                In Stock
              </div>
              <div className="text-content" />
            </div>
            <div className="card-2">
              <div className="image-wrapper">
                <div className="image">
                  <div className="title-2">Crisp Lettuce</div>
                </div>
              </div>
              <div className="text-content-2">
                <div className="title-3">Lettuce</div>
                <div className="subtitle-2">In Stock</div>
              </div>
            </div>
            <div className="card-2">
              <div className="image-wrapper">
                <div className="image">
                  <div className="title-2">Juicy Oranges</div>
                </div>
              </div>
              <div className="text-content-2">
                <div className="title-3">Oranges</div>
                <div className="subtitle-2">In Stock</div>
              </div>
            </div>
          </div>
        </div>
        <img className="img" alt="Vector" src="https://c.animaapp.com/GXcfFNUM/img/vector-200-1.svg" />
      </div>
      <div className="section-3">
        <div className="title-wrapper">
          <div className="title-4">What Our Customers Say</div>
        </div>
        <div className="list-2">
          <div className="card-3">
            <div className="user">
              <div className="avatar">
                <div className="avatar-2" />
                <div className="frame">
                  <div className="title-5">Alice</div>
                </div>
              </div>
              <img className="frame-2" alt="Frame" src="https://c.animaapp.com/GXcfFNUM/img/frame-427318817-1.svg" />
            </div>
            <p className="p">The produce I ordered was fresh and delicious. Highly recommend Sebees Fresh Food!</p>
          </div>
          <div className="card-4">
            <div className="user">
              <div className="avatar">
                <div className="avatar-2" />
                <div className="frame">
                  <div className="title-5">Bob</div>
                </div>
              </div>
              <img className="frame-2" alt="Frame" src="https://c.animaapp.com/GXcfFNUM/img/frame-427318817-1.svg" />
            </div>
            <p className="p">
              I love the convenience of having farm-fresh produce delivered right to my door. The taste is unbeatable!
            </p>
          </div>
        </div>
        <img className="vector-2" alt="Vector" src="https://c.animaapp.com/GXcfFNUM/img/vector-200-1.svg" />
      </div>
    </div>
  );
};
